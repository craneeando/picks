import React from 'react';

function home() {
  return (
    <div className=''>
        <p>this is home page</p>
    </div>
  )
}

export default home